/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'futuristic': ['Orbitron', 'Exo 2', 'monospace'],
        'tech': ['Exo 2', 'sans-serif'],
      },
      letterSpacing: {
        'ultra-wide': '0.15em',
        'tech': '0.08em',
      }
    },
  },
  plugins: [],
};
