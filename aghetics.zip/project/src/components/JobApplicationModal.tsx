import React, { useState } from 'react';
import { X, Users, User, Mail, Phone, Building, FileText, Upload, Send, MapPin, Calendar } from 'lucide-react';

interface JobApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const JobApplicationModal: React.FC<JobApplicationModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    nome: '',
    cognome: '',
    email: '',
    telefono: '',
    dataNascita: '',
    citta: '',
    provincia: '',
    titoloDiStudio: '',
    esperienza: '',
    posizioneDiInteresse: '',
    disponibilita: '',
    consensoPrivacy: false,
    consensoNewsletter: false
  });

  const [cvFile, setCvFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({
        ...prev,
        [name]: checked
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Verifica che sia un PDF o DOC/DOCX
      const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (allowedTypes.includes(file.type)) {
        setCvFile(file);
      } else {
        alert('Formato file non supportato. Carica un file PDF, DOC o DOCX.');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.consensoPrivacy) {
      alert('È necessario accettare il trattamento dei dati personali per procedere.');
      return;
    }

    setIsSubmitting(true);

    // Simula invio form con CV
    await new Promise(resolve => setTimeout(resolve, 2500));

    // Reset form e chiudi modal
    setFormData({
      nome: '',
      cognome: '',
      email: '',
      telefono: '',
      dataNascita: '',
      citta: '',
      provincia: '',
      titoloDiStudio: '',
      esperienza: '',
      posizioneDiInteresse: '',
      disponibilita: '',
      consensoPrivacy: false,
      consensoNewsletter: false
    });
    
    setCvFile(null);
    setIsSubmitting(false);
    onClose();
    
    alert('Candidatura inviata con successo! Ti contatteremo presto per valutare il tuo profilo.');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      ></div>

      {/* Modal */}
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-gray-900/95 backdrop-blur-lg rounded-2xl border border-purple-500/30 shadow-2xl shadow-purple-500/20 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white futuristic-title">Unisciti a noi</h2>
              <p className="text-white/80 futuristic-text">Invia la tua candidatura per entrare nel team AGETHICS</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Form */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Dati Personali */}
            <div className="bg-gray-800/30 rounded-xl p-6 border border-purple-500/20">
              <h3 className="text-xl font-bold text-white mb-4 futuristic-text flex items-center">
                <User className="w-5 h-5 mr-2" />
                Dati Personali
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">Nome *</label>
                  <input
                    type="text"
                    name="nome"
                    value={formData.nome}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                    placeholder="Il tuo nome"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">Cognome *</label>
                  <input
                    type="text"
                    name="cognome"
                    value={formData.cognome}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                    placeholder="Il tuo cognome"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">
                    <Mail className="w-4 h-4 inline mr-2" />
                    Email *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                    placeholder="nome@esempio.it"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">
                    <Phone className="w-4 h-4 inline mr-2" />
                    Telefono *
                  </label>
                  <input
                    type="tel"
                    name="telefono"
                    value={formData.telefono}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                    placeholder="+39 123 456 7890"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">
                    <Calendar className="w-4 h-4 inline mr-2" />
                    Data di nascita
                  </label>
                  <input
                    type="date"
                    name="dataNascita"
                    value={formData.dataNascita}
                    onChange={handleInputChange}
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
                  />
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">
                    <MapPin className="w-4 h-4 inline mr-2" />
                    Città di residenza
                  </label>
                  <input
                    type="text"
                    name="citta"
                    value={formData.citta}
                    onChange={handleInputChange}
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                    placeholder="Roma"
                  />
                </div>
              </div>
            </div>

            {/* Formazione ed Esperienza */}
            <div className="bg-gray-800/30 rounded-xl p-6 border border-purple-500/20">
              <h3 className="text-xl font-bold text-white mb-4 futuristic-text flex items-center">
                <Building className="w-5 h-5 mr-2" />
                Formazione ed Esperienza
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">Titolo di studio *</label>
                  <select
                    name="titoloDiStudio"
                    value={formData.titoloDiStudio}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
                  >
                    <option value="">Seleziona titolo di studio</option>
                    <option value="diploma">Diploma di Scuola Superiore</option>
                    <option value="laurea-triennale">Laurea Triennale</option>
                    <option value="laurea-magistrale">Laurea Magistrale</option>
                    <option value="master">Master</option>
                    <option value="dottorato">Dottorato</option>
                    <option value="altro">Altro</option>
                  </select>
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">Anni di esperienza</label>
                  <select
                    name="esperienza"
                    value={formData.esperienza}
                    onChange={handleInputChange}
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
                  >
                    <option value="">Seleziona esperienza</option>
                    <option value="0-1">0-1 anni (Junior)</option>
                    <option value="2-5">2-5 anni (Mid-level)</option>
                    <option value="5-10">5-10 anni (Senior)</option>
                    <option value="10+">10+ anni (Expert)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Posizione di Interesse */}
            <div className="bg-gray-800/30 rounded-xl p-6 border border-purple-500/20">
              <h3 className="text-xl font-bold text-white mb-4 futuristic-text">Posizione di Interesse</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">Area di interesse *</label>
                  <select
                    name="posizioneDiInteresse"
                    value={formData.posizioneDiInteresse}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
                  >
                    <option value="">Seleziona area</option>
                    <option value="sviluppo-software">Sviluppo Software</option>
                    <option value="ui-ux-design">UI/UX Design</option>
                    <option value="ai-machine-learning">AI & Machine Learning</option>
                    <option value="realta-virtuale">Realtà Virtuale/Aumentata</option>
                    <option value="project-management">Project Management</option>
                    <option value="marketing-digitale">Marketing Digitale</option>
                    <option value="ricerca-sviluppo">Ricerca e Sviluppo</option>
                    <option value="consulenza">Consulenza</option>
                    <option value="altro">Altro</option>
                  </select>
                </div>
                <div>
                  <label className="block text-white font-semibold mb-2 futuristic-text">Disponibilità</label>
                  <select
                    name="disponibilita"
                    value={formData.disponibilita}
                    onChange={handleInputChange}
                    className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
                  >
                    <option value="">Seleziona disponibilità</option>
                    <option value="full-time">Full-time</option>
                    <option value="part-time">Part-time</option>
                    <option value="freelance">Freelance/Consulenza</option>
                    <option value="stage">Stage/Tirocinio</option>
                    <option value="remoto">Lavoro Remoto</option>
                  </select>
                </div>
              </div>
            </div>

            {/* CV Upload */}
            <div className="bg-gray-800/30 rounded-xl p-6 border border-purple-500/20">
              <h3 className="text-xl font-bold text-white mb-4 futuristic-text flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                Curriculum Vitae
              </h3>
              
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  <Upload className="w-4 h-4 inline mr-2" />
                  Carica il tuo CV * (PDF, DOC, DOCX - Max 5MB)
                </label>
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileChange}
                  required
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-500 file:text-white hover:file:bg-purple-600 futuristic-text"
                />
                {cvFile && (
                  <p className="text-green-400 text-sm mt-2 futuristic-text">
                    File caricato: {cvFile.name}
                  </p>
                )}
              </div>
            </div>

            {/* Privacy e Consensi */}
            <div className="bg-gray-800/30 rounded-xl p-6 border border-purple-500/20">
              <h3 className="text-xl font-bold text-white mb-4 futuristic-text">Privacy e Consensi</h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    name="consensoPrivacy"
                    checked={formData.consensoPrivacy}
                    onChange={handleInputChange}
                    required
                    className="mt-1 w-4 h-4 text-purple-500 bg-gray-800 border-purple-500 rounded focus:ring-purple-500"
                  />
                  <label className="text-white text-sm futuristic-text">
                    Accetto il trattamento dei miei dati personali secondo la Privacy Policy di AGETHICS per la valutazione della candidatura. *
                  </label>
                </div>

                <div className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    name="consensoNewsletter"
                    checked={formData.consensoNewsletter}
                    onChange={handleInputChange}
                    className="mt-1 w-4 h-4 text-purple-500 bg-gray-800 border-purple-500 rounded focus:ring-purple-500"
                  />
                  <label className="text-white text-sm futuristic-text">
                    Desidero ricevere aggiornamenti su opportunità lavorative e novità AGETHICS.
                  </label>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center pt-4">
              <button
                type="submit"
                disabled={isSubmitting || !formData.consensoPrivacy}
                className="px-8 py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed futuristic-nav"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Invio candidatura...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    <span>Invia Candidatura</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default JobApplicationModal;