import React, { useState } from 'react';
import { X, Calendar, User, Mail, Phone, Building, MessageSquare, Send } from 'lucide-react';

interface DemoBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DemoBookingModal: React.FC<DemoBookingModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    nome: '',
    cognome: '',
    email: '',
    telefono: '',
    azienda: '',
    ruolo: '',
    servizio: '',
    messaggio: '',
    dataPreferita: '',
    orarioPreferito: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simula invio form
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Reset form e chiudi modal
    setFormData({
      nome: '',
      cognome: '',
      email: '',
      telefono: '',
      azienda: '',
      ruolo: '',
      servizio: '',
      messaggio: '',
      dataPreferita: '',
      orarioPreferito: ''
    });
    
    setIsSubmitting(false);
    onClose();
    
    // Mostra messaggio di successo (potresti implementare un toast)
    alert('Richiesta demo inviata con successo! Ti contatteremo presto.');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      ></div>

      {/* Modal */}
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-gray-900/95 backdrop-blur-lg rounded-2xl border border-purple-500/30 shadow-2xl shadow-purple-500/20 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white futuristic-title">Prenota una Demo</h2>
              <p className="text-white/80 futuristic-text">Scopri le nostre soluzioni innovative</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Form */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Dati Personali */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  <User className="w-4 h-4 inline mr-2" />
                  Nome *
                </label>
                <input
                  type="text"
                  name="nome"
                  value={formData.nome}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                  placeholder="Il tuo nome"
                />
              </div>
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  Cognome *
                </label>
                <input
                  type="text"
                  name="cognome"
                  value={formData.cognome}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                  placeholder="Il tuo cognome"
                />
              </div>
            </div>

            {/* Contatti */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  <Mail className="w-4 h-4 inline mr-2" />
                  Email *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                  placeholder="nome@esempio.it"
                />
              </div>
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  <Phone className="w-4 h-4 inline mr-2" />
                  Telefono
                </label>
                <input
                  type="tel"
                  name="telefono"
                  value={formData.telefono}
                  onChange={handleInputChange}
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                  placeholder="+39 123 456 7890"
                />
              </div>
            </div>

            {/* Azienda e Ruolo */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  <Building className="w-4 h-4 inline mr-2" />
                  Azienda/Ente
                </label>
                <input
                  type="text"
                  name="azienda"
                  value={formData.azienda}
                  onChange={handleInputChange}
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                  placeholder="Nome azienda"
                />
              </div>
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  Ruolo
                </label>
                <input
                  type="text"
                  name="ruolo"
                  value={formData.ruolo}
                  onChange={handleInputChange}
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none futuristic-text"
                  placeholder="Il tuo ruolo"
                />
              </div>
            </div>

            {/* Servizio di Interesse */}
            <div>
              <label className="block text-white font-semibold mb-2 futuristic-text">
                Servizio di interesse
              </label>
              <select
                name="servizio"
                value={formData.servizio}
                onChange={handleInputChange}
                className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
              >
                <option value="">Seleziona un servizio</option>
                <option value="sviluppo-software">Sviluppo Software e Applicazioni</option>
                <option value="eduverso">Eduverso & Tecnologie Immersive</option>
                <option value="consulenza">Consulenza e Formazione Digitale</option>
                <option value="ricerca">Ricerca e Sviluppo Etico</option>
                <option value="visionai">VisionAI</option>
                <option value="altro">Altro</option>
              </select>
            </div>

            {/* Data e Orario Preferiti */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  Data preferita
                </label>
                <input
                  type="date"
                  name="dataPreferita"
                  value={formData.dataPreferita}
                  onChange={handleInputChange}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
                />
              </div>
              <div>
                <label className="block text-white font-semibold mb-2 futuristic-text">
                  Orario preferito
                </label>
                <select
                  name="orarioPreferito"
                  value={formData.orarioPreferito}
                  onChange={handleInputChange}
                  className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:border-purple-500 focus:outline-none futuristic-text"
                >
                  <option value="">Seleziona orario</option>
                  <option value="09:00">09:00</option>
                  <option value="10:00">10:00</option>
                  <option value="11:00">11:00</option>
                  <option value="14:00">14:00</option>
                  <option value="15:00">15:00</option>
                  <option value="16:00">16:00</option>
                  <option value="17:00">17:00</option>
                </select>
              </div>
            </div>

            {/* Messaggio */}
            <div>
              <label className="block text-white font-semibold mb-2 futuristic-text">
                <MessageSquare className="w-4 h-4 inline mr-2" />
                Messaggio aggiuntivo
              </label>
              <textarea
                name="messaggio"
                value={formData.messaggio}
                onChange={handleInputChange}
                rows={4}
                className="w-full bg-gray-800/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none resize-none futuristic-text"
                placeholder="Descrivi brevemente le tue esigenze o domande specifiche..."
              ></textarea>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-8 py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 text-white rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed futuristic-nav"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Invio in corso...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    <span>Prenota Demo</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default DemoBookingModal;