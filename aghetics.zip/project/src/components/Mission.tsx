import React from 'react';
import { Eye } from 'lucide-react';

const Mission = () => {
  return (
    <section id="mission" className="py-20 bg-gray-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-4xl sm:text-5xl font-bold mb-12 bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent futuristic-title">
            La nostra mission
          </h2>
          
          <div className="max-w-4xl mx-auto space-y-8">
            <p className="text-xl text-gray-300 leading-relaxed futuristic-text">
              Vogliamo costruire un futuro dove la tecnologia migliori la vita delle persone in modo etico, trasparente e sostenibile.
            </p>
            
            <p className="text-lg text-gray-300 leading-relaxed futuristic-text">
              Lavoriamo per creare valore condiviso, favorire l'inclusione e generare un impatto positivo sulla società.
            </p>
          </div>

          <div className="mt-16 mb-12">
            <div className="w-20 h-20 bg-gradient-to-r from-cyan-400 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-8">
              <Eye className="w-10 h-10 text-white" />
            </div>
            
            <h3 className="text-3xl font-bold text-white mb-6 futuristic-text">Vision</h3>
            
            <p className="text-xl leading-relaxed futuristic-text">
              <span className="text-pink-400">Innovazione etica</span>
              <span className="text-gray-300"> al servizio delle </span>
              <span className="text-cyan-400">comunità.</span>
            </p>
          </div>

          <div className="mt-16">
            <div className="inline-block p-8 border-2 border-transparent bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-cyan-400/20 rounded-2xl backdrop-blur-lg relative">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 rounded-2xl opacity-50 blur-sm"></div>
              <div className="absolute inset-[2px] bg-gray-900/80 rounded-2xl"></div>
              <div className="relative">
                <p className="text-2xl font-bold text-pink-400 futuristic-text">
                  Insieme per un digitale più umano.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Mission;