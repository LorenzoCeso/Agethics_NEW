import React, { useState } from 'react';
import { ArrowRight, ChevronDown } from 'lucide-react';
import ParticleSystem from './ParticleSystem';
import LEDTitle from './LEDTitle';

const Hero = () => {
  const [isParticlesActive] = useState(true);

  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-purple-900 via-gray-900 to-cyan-900">
      {/* Particle System */}
      <ParticleSystem isActive={isParticlesActive} />
      
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/40 via-pink-900/20 to-cyan-900/40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15),transparent_50%)]"></div>
      
      {/* Animated Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="space-y-8">
          <LEDTitle />
          
          <p className="text-xl sm:text-2xl text-gray-300 max-w-3xl mx-auto futuristic-text">
            Soluzioni digitali avanzate, sostenibili e inclusive.
          </p>
          
          <p className="text-lg text-gray-400 max-w-4xl mx-auto futuristic-text">
            AGETHICS sviluppa software, applicazioni e ambienti immersivi per scuole, aziende e pubbliche amministrazioni, unendo tecnologia ed etica.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mt-12">
            <button
              onClick={scrollToAbout}
              className="group px-8 py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 rounded-full font-semibold text-white hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 futuristic-nav"
            >
              <span>Scopri di più</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button
              onClick={scrollToContact}
              className="px-8 py-4 border-2 border-purple-500 text-purple-400 rounded-full font-semibold hover:bg-purple-500 hover:text-white hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 futuristic-nav"
            >
              Contattaci
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-gray-400 hover:text-purple-400 transition-colors animate-bounce"
      >
        <ChevronDown className="w-6 h-6" />
      </button>
    </section>
  );
};

export default Hero;