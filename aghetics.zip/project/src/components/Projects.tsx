import React from 'react';
import { Zap, ArrowRight } from 'lucide-react';

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-gray-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 futuristic-title">
            <span className="bg-gradient-to-r from-pink-400 via-gray-300 to-cyan-400 bg-clip-text text-transparent">
              I nostri progetti
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto futuristic-text">
            Ogni progetto AGETHICS nasce per rispondere a un bisogno reale, creando valore per la società.
          </p>
        </div>

        {/* Main Project Card */}
        <div className="max-w-4xl mx-auto mb-16">
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20 hover:border-purple-500/40 transition-all duration-300">
            {/* Project Header */}
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-3xl font-bold text-white mb-2 futuristic-text">VisionAI</h3>
                <p className="text-purple-400 futuristic-text">Progetto di punta</p>
              </div>
            </div>

            {/* Project Description */}
            <p className="text-gray-300 text-lg leading-relaxed mb-8 futuristic-text">
              Una piattaforma di intelligenza artificiale etica che supporta la formazione attraverso ambienti virtuali immersivi. VisionAI combina machine learning responsabile con tecnologie VR/AR per creare esperienze educative personalizzate e inclusive.
            </p>

            {/* Features Grid */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <h4 className="text-lg font-bold text-white mb-3 futuristic-text">AI Etica</h4>
                <p className="text-gray-400 text-sm futuristic-text">
                  Algoritmi trasparenti che rispettano la privacy e i diritti umani
                </p>
              </div>
              <div className="text-center">
                <h4 className="text-lg font-bold text-white mb-3 futuristic-text">Realtà Virtuale</h4>
                <p className="text-gray-400 text-sm futuristic-text">
                  Ambienti immersivi per un apprendimento coinvolgente
                </p>
              </div>
              <div className="text-center">
                <h4 className="text-lg font-bold text-white mb-3 futuristic-text">Accessibilità</h4>
                <p className="text-gray-400 text-sm futuristic-text">
                  Soluzioni inclusive per tutti i tipi di apprendimento
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="group px-8 py-3 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 rounded-full font-semibold text-white hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 futuristic-nav">
                <span>Scopri VisionAI</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              
              <button className="px-8 py-3 border-2 border-cyan-400 text-cyan-400 rounded-full font-semibold hover:bg-cyan-400 hover:text-gray-900 hover:shadow-lg hover:shadow-cyan-400/25 transition-all duration-300 transform hover:scale-105 futuristic-nav">
                Scarica la brochure
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;