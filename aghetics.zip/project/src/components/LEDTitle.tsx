import React from 'react';

const LEDTitle: React.FC = () => {
  return (
    <h1 className="font-bold leading-tight futuristic-title">
      <span className="block relative">
        <span className="text-4xl sm:text-6xl lg:text-7xl bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent tracking-wider">
          Innovazione etica
        </span>
      </span>
      <span className="block text-3xl sm:text-4xl lg:text-5xl text-white mt-2 futuristic-title tracking-wide">
        per un futuro migliore
      </span>
    </h1>
  );
};

export default LEDTitle;