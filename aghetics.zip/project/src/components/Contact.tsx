import React from 'react';
import { MapPin, Phone, Mail, Send, ArrowRight } from 'lucide-react';
import DemoBookingModal from './DemoBookingModal';
import JobApplicationModal from './JobApplicationModal';

const Contact = () => {
  const [isDemoModalOpen, setIsDemoModalOpen] = React.useState(false);
  const [isJobModalOpen, setIsJobModalOpen] = React.useState(false);

  return (
    <section id="contact" className="py-20 bg-gray-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-pink-400 via-gray-300 to-cyan-400 bg-clip-text text-transparent futuristic-title">
            Contattaci
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto futuristic-text">
            Scrivici per ricevere maggiori informazioni, proporre collaborazioni o sviluppare insieme un progetto innovativo.
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Left Column - Company Info */}
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20">
            <h3 className="text-2xl font-bold text-white mb-8 futuristic-text">AGETHICS S.r.l.s. Unipersonale</h3>
            
            <div className="space-y-6">
              {/* Address */}
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white mb-1 futuristic-text">Indirizzo</h4>
                  <p className="text-gray-300 futuristic-text">Via Virgilio n. 7</p>
                  <p className="text-gray-300 futuristic-text">CAP 00058, Santa Marinella [RM]</p>
                </div>
              </div>

              {/* Phone */}
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white mb-1 futuristic-text">Telefono</h4>
                  <p className="text-gray-300 futuristic-text">+39 0766809678</p>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white mb-1 futuristic-text">Email</h4>
                  <p className="text-gray-300 futuristic-text">info@agethics.it</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Quick Actions */}
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20">
            <h3 className="text-2xl font-bold text-white mb-8 futuristic-text">Inizia subito</h3>
            
            <div className="space-y-4">
              {/* Join Us Button */}
              <button 
                onClick={() => setIsJobModalOpen(true)}
                className="w-full px-6 py-4 bg-gradient-to-r from-pink-500 via-purple-500 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 futuristic-nav"
              >
                <span>Unisciti a noi</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* Book Demo Button */}
              <button 
                onClick={() => setIsDemoModalOpen(true)}
                className="w-full px-6 py-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-cyan-400/25 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 futuristic-nav"
              >
                <span>Prenota una demo</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* Talk to Expert Button */}
              <button className="w-full px-6 py-4 bg-gray-800/50 border-2 border-purple-500/50 text-white rounded-lg font-semibold hover:bg-purple-500/20 hover:border-purple-500 hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 futuristic-nav">
                <span>Parla con un esperto</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* Download Brochure Button */}
              <button className="w-full px-6 py-4 bg-gray-800/50 border-2 border-cyan-400/50 text-cyan-400 rounded-lg font-semibold hover:bg-cyan-400/20 hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-400/25 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 futuristic-nav">
                <span>Scarica la brochure</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

      </div>

      <JobApplicationModal 
        isOpen={isJobModalOpen} 
        onClose={() => setIsJobModalOpen(false)} 
      />
    </section>
  );
};

export default Contact;