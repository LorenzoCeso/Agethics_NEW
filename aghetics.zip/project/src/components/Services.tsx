import React from 'react';
import { Code, Globe, Search, Microscope } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Code,
      title: 'Sviluppo software e applicazioni',
      description: 'Creiamo software personalizzati, applicazioni web e mobile, piattaforme digitali e ambienti virtuali, con un forte focus su accessibilità, usabilità e sicurezza.',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Globe,
      title: 'Eduverso & tecnologie immersive',
      description: 'Realizziamo mondi virtuali, avatar interattivi e simulazioni educative per apprendere in modo immersivo e coinvolgente, a scuola e in azienda.',
      gradient: 'from-pink-500 to-cyan-400'
    },
    {
      icon: Search,
      title: 'Consulenza e formazione digitale',
      description: 'Affianchiamo enti e imprese nella transizione digitale, con percorsi di formazione su misura per sviluppare competenze tecnologiche e strategiche.',
      gradient: 'from-cyan-400 to-purple-500'
    },
    {
      icon: Microscope,
      title: 'Ricerca e sviluppo etico',
      description: 'Investiamo in ricerca e sperimentazione nel campo dell\'AI, della realtà aumentata e delle soluzioni intelligenti, rispettando privacy e diritti umani.',
      gradient: 'from-purple-500 via-pink-500 to-cyan-400'
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent futuristic-title">
            I nostri servizi
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto futuristic-text">
            Progettiamo innovazione per la formazione, il business e la pubblica amministrazione.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 hover:transform hover:-translate-y-2 hover:shadow-xl hover:shadow-purple-500/10"
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className={`w-16 h-16 bg-gradient-to-r ${service.gradient} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {service.title}
                </h3>
              </div>
              <p className="text-gray-300 leading-relaxed group-hover:text-gray-200 transition-colors futuristic-text">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;