import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  color: string;
  baseSize: number;
  pulseSpeed: number;
  pulseOffset: number;
}

interface ParticleSystemProps {
  isActive: boolean;
}

const ParticleSystem: React.FC<ParticleSystemProps> = ({ isActive }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animationRef = useRef<number>();
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initialize particles with constant slow movement
    const initParticles = () => {
      particlesRef.current = [];
      const particleCount = 80;
      const colors = ['#E879F9', '#A855F7', '#06B6D4', '#22D3EE', '#8B5CF6', '#EC4899'];
      
      for (let i = 0; i < particleCount; i++) {
        const baseSize = Math.random() * 3 + 1.5;
        // Velocità costante molto lenta
        const speed = 0.3;
        const angle = Math.random() * Math.PI * 2;
        
        particlesRef.current.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: baseSize,
          baseSize: baseSize,
          opacity: Math.random() * 0.6 + 0.3,
          color: colors[Math.floor(Math.random() * colors.length)],
          pulseSpeed: Math.random() * 0.01 + 0.005,
          pulseOffset: Math.random() * Math.PI * 2
        });
      }
    };

    initParticles();

    const animate = () => {
      timeRef.current += 0.016;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particlesRef.current.forEach((particle, index) => {
        // Movimento costante - nessuna accelerazione o variazione
        particle.x += particle.vx;
        particle.y += particle.vy;

        // Boundary wrapping
        if (particle.x < -10) particle.x = canvas.width + 10;
        if (particle.x > canvas.width + 10) particle.x = -10;
        if (particle.y < -10) particle.y = canvas.height + 10;
        if (particle.y > canvas.height + 10) particle.y = -10;

        // Pulsazione molto leggera solo per la dimensione
        const pulseMultiplier = 1 + Math.sin(timeRef.current * particle.pulseSpeed + particle.pulseOffset) * 0.2;
        particle.size = particle.baseSize * pulseMultiplier;

        // Opacità costante con leggera variazione
        const baseOpacity = 0.5 + Math.sin(timeRef.current * particle.pulseSpeed * 0.5 + particle.pulseOffset) * 0.2;
        particle.opacity = Math.max(0.2, Math.min(0.8, baseOpacity));

        // Draw particle
        ctx.save();
        ctx.globalAlpha = particle.opacity;
        ctx.fillStyle = particle.color;
        
        // Glow effect
        ctx.shadowBlur = 20;
        ctx.shadowColor = particle.color;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();

        // Inner glow
        ctx.shadowBlur = 10;
        ctx.globalAlpha = particle.opacity * 0.7;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size * 0.6, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();

        // Connessioni statiche tra particelle vicine
        particlesRef.current.slice(index + 1).forEach(otherParticle => {
          const dx = particle.x - otherParticle.x;
          const dy = particle.y - otherParticle.y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 120) {
            const connectionOpacity = (120 - distance) / 120 * 0.3;

            ctx.save();
            ctx.globalAlpha = connectionOpacity * particle.opacity * otherParticle.opacity;
            ctx.strokeStyle = particle.color;
            ctx.lineWidth = 1;
            ctx.shadowBlur = 5;
            ctx.shadowColor = particle.color;
            
            ctx.beginPath();
            ctx.moveTo(particle.x, particle.y);
            ctx.lineTo(otherParticle.x, otherParticle.y);
            ctx.stroke();
            ctx.restore();
          }
        });
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none"
      style={{ zIndex: 1 }}
    />
  );
};

export default ParticleSystem;