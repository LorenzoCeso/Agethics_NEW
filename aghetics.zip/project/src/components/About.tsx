import React from 'react';
import { Heart, Users, Lightbulb } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gray-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Titolo Chi siamo */}
        <div className="text-center mb-12">
          <h2 className="text-4xl sm:text-5xl font-bold mb-8 bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent futuristic-title">
            Chi siamo
          </h2>
        </div>

        {/* Testi descrittivi */}
        <div className="text-center mb-16 space-y-6">
          <p className="text-lg text-gray-300 max-w-4xl mx-auto leading-relaxed futuristic-text">
            AGETHICS nasce per mettere la tecnologia al servizio delle persone. Crediamo che l'innovazione debba essere etica, inclusiva e realmente utile alla comunità.
          </p>
          
          <p className="text-lg text-gray-300 max-w-5xl mx-auto leading-relaxed futuristic-text">
            Progettiamo software, applicazioni e soluzioni immersive con l'obiettivo di migliorare la formazione, il lavoro e la vita quotidiana. Collaboriamo con scuole, università, enti pubblici e imprese per costruire un futuro digitale più umano, sostenibile e responsabile.
          </p>
        </div>

        {/* Central Box */}
        <div className="flex justify-center mb-16">
          <div className="relative">
            <div className="bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border-2 border-pink-500/60 hover:border-pink-500/80 transition-all duration-300 max-w-2xl">
              <h3 className="text-2xl sm:text-3xl font-bold text-center text-gray-200 futuristic-text">
                Tecnologia etica, innovazione sostenibile.
              </h3>
            </div>
          </div>
        </div>

        {/* Three Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Etica Card */}
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20 hover:border-pink-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/10 text-center">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                <Heart className="w-8 h-8 text-white" />
              </div>
            </div>
            <h4 className="text-xl font-bold text-white mb-4 futuristic-text">Etica</h4>
            <p className="text-gray-300 leading-relaxed futuristic-text">
              Ogni progetto è guidato da principi etici che mettono al centro la dignità umana e il benessere collettivo.
            </p>
          </div>

          {/* Inclusività Card */}
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10 text-center">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
            </div>
            <h4 className="text-xl font-bold text-white mb-4 futuristic-text">Inclusività</h4>
            <p className="text-gray-300 leading-relaxed futuristic-text">
              Creiamo soluzioni accessibili a tutti, abbattendo barriere tecnologiche e promuovendo l'uguaglianza digitale.
            </p>
          </div>

          {/* Innovazione Card */}
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10 text-center">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <Lightbulb className="w-8 h-8 text-white" />
              </div>
            </div>
            <h4 className="text-xl font-bold text-white mb-4 futuristic-text">Innovazione</h4>
            <p className="text-gray-300 leading-relaxed futuristic-text">
              Esploriamo le frontiere della tecnologia per sviluppare soluzioni innovative che rispondano ai bisogni reali.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;