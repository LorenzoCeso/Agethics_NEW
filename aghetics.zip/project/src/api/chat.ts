// API route for ChatGPT integration
// This would typically be implemented in a backend service

export async function POST(request: Request) {
  try {
    const { message, context } = await request.json();

    // Replace with your actual OpenAI API key
    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

    if (!OPENAI_API_KEY) {
      throw new Error('OpenAI API key not configured');
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `Sei l'assistente virtuale di AGETHICS, un'azienda italiana che sviluppa software etico e sostenibile. AGETHICS si occupa di:
            - Sviluppo software e applicazioni
            - Tecnologie immersive e Eduverso
            - Consulenza e formazione digitale
            - Ricerca e sviluppo etico
            
            Rispondi sempre in italiano, sii professionale ma amichevole, e fornisci informazioni utili sui servizi AGETHICS. Se non sai qualcosa, suggerisci di contattare info@agethics.it o +39 0766809678.`
          },
          {
            role: 'user',
            content: message
          }
        ],
        max_tokens: 150,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error('OpenAI API request failed');
    }

    const data = await response.json();
    const botResponse = data.choices[0]?.message?.content || 'Mi dispiace, non sono riuscito a elaborare la tua richiesta.';

    return new Response(JSON.stringify({ response: botResponse }), {
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Chat API error:', error);
    
    return new Response(
      JSON.stringify({ 
        response: 'Mi dispiace, si è verificato un errore. Per assistenza immediata, contatta info@agethics.it o chiama +39 0766809678.' 
      }),
      { 
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      }
    );
  }
}